# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['pelican', 'pelican.plugins.pelican_algolia']

package_data = \
{'': ['*']}

install_requires = \
['algoliasearch>=2.6.0', 'pelican>=4.5']

extras_require = \
{'markdown': ['markdown>=3.2']}

setup_kwargs = {
    'name': 'pelican-algolia',
    'version': '1.0.1',
    'description': 'Plugin to add Algolia Search to Pelican SSG',
    'long_description': 'Algolia Search: A Plugin for Pelican\n====================================================\n\n[![Build Status](https://img.shields.io/github/workflow/status/rehanhaider/pelican-algolia/build)](https://github.com/rehanhaider/pelican-algolia/actions)\n[![PyPI Version](https://img.shields.io/pypi/v/pelican-algolia)](https://pypi.org/project/pelican-algolia/)\n![License](https://img.shields.io/pypi/l/pelican-algolia?color=blue)\n\n\nInstallation\n------------\n\nThis plugin can be installed via:\n\n    python -m pip install pelican-algolia\n\nUsage\n-----\n\n<<Add plugin details here>>\n\nContributing\n------------\n\nContributions are welcome and much appreciated. Every little bit helps. You can contribute by improving the documentation, adding missing features, and fixing bugs. You can also help out by reviewing and commenting on [existing issues][].\n\nTo start contributing to this plugin, review the [Contributing to Pelican][] documentation, beginning with the **Contributing Code** section.\n\n[existing issues]: https://github.com/rehanhaider/pelican-algolia/issues\n[Contributing to Pelican]: https://docs.getpelican.com/en/latest/contribute.html\n\nLicense\n-------\n\nThis project is licensed under the AGPL-3.0 license.\n',
    'author': 'Rehan Haider',
    'author_email': 'email@rehanhaider.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': 'https://github.com/rehanhaider/pelican-algolia',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'extras_require': extras_require,
    'python_requires': '>=3.6.2,<4.0',
}


setup(**setup_kwargs)

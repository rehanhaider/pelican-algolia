from .pelican_algolia import *  # NOQA
